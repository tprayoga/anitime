Fitur Import CSV
Fitur ini memungkinkan pengguna untuk mengimpor data dari file CSV ke dalam aplikasi dengan mudah.

1. Unduh file CSV 
2. Silahkan Modifikasi Data Sesuai Dengan Format yang telah diberikan
3. Unggah file CSV, lalu sistem akan menampilkan berapa data yang berhasil dan gagal saat import.
4. Sistem akan mengembalikan data yang gagal saat import 

Aturan Format setiap kolom : 
-No FID : required,
-Lokasi : required, pilihan : Telinga Kiri, Telinga Kanan
-Jenis Hewan : required, pilihan : Sapi Perah, Sapi Jantan
-Jenis Breed : required 
-Warna : required
-Body Conditional Score : required
-Berat : required (dalam satuan kg)
-Umur : required, (dalam satuan hari)
-Tanggal Lahir : required, format : 'dd-mm-yyyy'
-Asal Peternakan : required
-RFID : required, unique
-ID PKH : required